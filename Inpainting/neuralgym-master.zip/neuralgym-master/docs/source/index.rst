.. NeuralGym documentation master file, created by
   sphinx-quickstart on Wed Nov 22 17:16:30 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

NeuralGym documentation
=======================

.. toctree::
   :glob:
   :maxdepth: 3
   :caption: Tutorials

   tutorials/*


.. toctree::
   :maxdepth: 3
   :caption: Package Reference

   neuralgym
   callbacks
   ops
   train
   utils
   data
