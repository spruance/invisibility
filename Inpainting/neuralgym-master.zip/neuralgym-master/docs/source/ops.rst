neuralgym.ops
=============


layers
------

.. automodule:: neuralgym.ops.layers
    :members:
    :no-undoc-members:

summary_ops
-----------

.. automodule:: neuralgym.ops.summary_ops
    :members:
    :no-undoc-members:

loss_ops
--------

.. automodule:: neuralgym.ops.loss_ops
    :members:
    :no-undoc-members:

image_ops
---------

.. automodule:: neuralgym.ops.image_ops
    :members:
    :no-undoc-members:

gan_ops
-------

.. automodule:: neuralgym.ops.gan_ops
    :members:
    :no-undoc-members:
